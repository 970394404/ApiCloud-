//
//  ViewController.m
//  ChatKeyboard
//
//  Created by Zanilia on 2017/6/13.
//  Copyright © 2017年 王宾. All rights reserved.
//

#import "ViewController.h"
#import "UIKeyboardBar.h"
#import "UIView+Methods.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate,UIKeyboardBarDelegate>

@property (nonatomic) UITableView *contentTableView;
@property (nonatomic) UIKeyboardBar *keyboardBar;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [self.view addSubview:self.contentTableView];
    [self.view addSubview:self.keyboardBar];

    // Do any additional setup after loading the view, typically from a nib.
}

- (UITableView *)contentTableView{
    if (_contentTableView == nil) {
        _contentTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, MainScreenSizeWidth, MainScreenSizeHeight-50) style:UITableViewStylePlain];
        _contentTableView.delegate = self;
        _contentTableView.dataSource = self;
        _contentTableView.rowHeight = 44;
        _contentTableView.tableFooterView = [UIView new];
        _contentTableView.backgroundView = [UIView new];
    }
    return _contentTableView;
}

- (UIKeyboardBar *)keyboardBar{
    if (_keyboardBar == nil) {
        _keyboardBar = [[UIKeyboardBar alloc]initWithFrame:CGRectZero];
        _keyboardBar.expressionBundleName = @"FaceExpression";
        _keyboardBar.barDelegate = self;
        _keyboardBar.KeyboardMoreImages = @[@"ToolVieMoreKeyboardCamera@2x",@"ToolVieMoreKeyboardPhotos@2x"];
        _keyboardBar.KeyboardMoreTitles = @[@"拍照",@"相册"];
        //keyboardTypes 可随意添加删除，但有一点UIKeyboardChatTypeKeyboard是默认有的
        _keyboardBar.keyboardTypes = @[@(UIKeyboardChatTypeVoice),@(UIKeyboardChatTypeFace)];
//        _keyboardBar.keyboardTypes = @[@(UIKeyboardChatTypeKeyboard),@(UIKeyboardChatTypeVoice),@(UIKeyboardChatTypeFace),@(UIKeyboardChatTypeMore)];
    }
    return _keyboardBar;
}

#pragma mark -- UITableViewDataSource --
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return tableView.height/44;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"UITableViewCell"];
    }
    return cell;
}

#pragma mark -- UITableViewDelegate --
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark -- UIScrollViewDelegate --
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    if ([scrollView isEqual:self.contentTableView]) {
        if (_keyboardBar.inputing) {
            [_keyboardBar endInput];
        }
    }
}

#pragma mark -- UIKeyboardBarDelegate --
- (void)keyboardBar:(UIKeyboardBar *)keyboard didChangeFrame:(CGRect)frame{
    if (frame.origin.y == self.contentTableView.frame.size.height) {
        return;
    }
    [UIView animateWithDuration:0.25f animations:^{
        [self.contentTableView setFrame:CGRectMake(0, 0, MainScreenSizeWidth, frame.origin.y)];
    } completion:^(BOOL finished) {
    }];
}

- (void)keyboardBar:(UIKeyboardBar *)keyboard moreHandleAtItemIndex:(NSInteger)index{
    NSLog(@"--------- \n选择更多操作 index = %ld",(long)index);
}

- (void)keyboardBar:(UIKeyboardBar *)keyboard sendContent:(NSString *)message{
    NSLog(@"--------- \n发送文本 message = %@",message);

}

- (void)keyboardBar:(UIKeyboardBar *)keyboard sendVoiceWithFilePath:(NSString *)path seconds:(NSTimeInterval)seconds{
    NSLog(@"--------- \n发送录制语音 path = %@,语音时长 = %lf",path,seconds);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
