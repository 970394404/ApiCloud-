//
//  AppDelegate.h
//  ChatKeyboard
//
//  Created by Zanilia on 2017/6/13.
//  Copyright © 2017年 王宾. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

